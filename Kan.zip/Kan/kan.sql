-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 24, 2024 at 11:23 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `zay_shop`
--

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE `account` (
  `acc_id` int(11) NOT NULL,
  `acc_username` varchar(60) NOT NULL,
  `acc_password` varchar(30) NOT NULL,
  `email` varchar(60) NOT NULL,
  `acc_role` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `account`
--

INSERT INTO `account` (`acc_id`, `acc_username`, `acc_password`, `email`, `acc_role`) VALUES
(1, 'hehehe', '123456', 'hunglaphu244@gmail.com', 'user'),
(2, 'admin', '123456', 'hunglaphu244@gmail.com', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `cate_id` varchar(20) NOT NULL,
  `cate_name` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`cate_id`, `cate_name`) VALUES
('DECORT1', 'Decorations'),
('KCT1', 'Keychain'),
('OET1', 'Office equipment'),
('SAVT1', 'Saving tube'),
('TOY1', 'Toy');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `contact_id` int(11) NOT NULL,
  `sender_name` varchar(60) NOT NULL,
  `sender_email` varchar(60) NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`contact_id`, `sender_name`, `sender_email`, `message`) VALUES
(2, 'Hệ', 'hunglaphu244@gmail.com', 'siuuuuuu');

-- --------------------------------------------------------

--
-- Table structure for table `order_info`
--

CREATE TABLE `order_info` (
  `order_id` int(11) NOT NULL,
  `acc_id` int(11) NOT NULL,
  `order_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `into_money` float NOT NULL,
  `shipping_status` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_info`
--

INSERT INTO `order_info` (`order_id`, `acc_id`, `order_date`, `into_money`, `shipping_status`) VALUES
(1, 1, '2024-05-20 14:34:14', 0, 'in progress'),
(2, 1, '2024-05-20 14:34:24', 2000, 'waiting for confirmation'),
(3, 1, '2024-05-20 14:34:30', 10560, 'waiting for confirmation'),
(4, 1, '2024-05-20 14:36:03', 100, 'waiting for confirmation'),
(5, 1, '2024-05-21 10:58:53', 400, 'waiting for confirmation'),
(6, 1, '2024-05-22 15:14:43', 20000000, 'waiting for confirmation'),
(7, 1, '2024-05-24 06:44:01', 300, 'waiting for confirmation');

-- --------------------------------------------------------

--
-- Table structure for table `order_products`
--

CREATE TABLE `order_products` (
  `order_id` int(11) NOT NULL,
  `prod_id` varchar(20) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_products`
--

INSERT INTO `order_products` (`order_id`, `prod_id`, `quantity`) VALUES
(1, 'CLS2405K', 3),
(2, 'DECOR1', 2),
(3, 'CLS2404B', 5),
(3, 'DECOR1', 10),
(3, 'KEY1', 6),
(4, 'CLS2405K', 1),
(5, 'CLS2405K', 4),
(6, 'CRISTIANO', 2),
(7, 'CLS2405K', 3);

--
-- Triggers `order_products`
--
DELIMITER $$
CREATE TRIGGER `increase_product_inventory` BEFORE INSERT ON `order_products` FOR EACH ROW UPDATE product SET product.inventory = product.inventory - NEW.quantity WHERE product.prod_id = NEW.prod_id
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `prod_id` varchar(20) NOT NULL,
  `prod_title` varchar(60) NOT NULL,
  `cate_id` varchar(20) NOT NULL,
  `price` float NOT NULL,
  `picture` varchar(100) NOT NULL,
  `prod_description` text NOT NULL,
  `inventory` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`prod_id`, `prod_title`, `cate_id`, `price`, `picture`, `prod_description`, `inventory`) VALUES
('CLS2404B', 'Dragon-shaped Savings Piggy Bank', 'SAVT1', 100, 'pig-1.jpg', 'Removable Anti-fall and Anti-Shatter Cartoon Dragon Saving Piggy Bank', 95),
('CLS2405K', 'Sailboat model', 'DECORT1', 100, 'decor-3.jpg', 'This product uses high quality wood, the wood grain on the surface will be different, and the wood texture is normal, does not affect the appearance of the product.', 89),
('CRISTIANO', 'CRISTIANO RONALDO', 'DECORT1', 10000000, 'decor-2.jpg', 'SIUUUUUUUUUUUUUU', 998),
('DECOR1', 'HOURGLASS, CRYSTAL BALL', 'DECORT1', 1000, 'decor-1.jpg', '- Size: 16*8*13cm\r\n- Weight: 0.8kg\r\n- Material: Iron, plastic, crystal glass\r\n- Color: bronze, silver\r\n- Sturdy metal frame, easy to place on surfaces\r\n- Decorative hourglass made from transparent glass with beautiful white sand grains', 88),
('KEY1', 'GUITAR KEYCHAIN', 'KCT1', 10, 'key.jpg', 'Guitar keychain made of high quality pine and model wood\r\n\r\n', 94),
('KEY2', 'SanNy conical hat keychain', 'KCT1', 25, 'key-2.jpg', '3cm white conical hat keychain\r\nThe product is used to hang airpods and phones\r\nMaterial: Plastic + metal keychain\r\nBecause the product is hand-painted and taken with a phone, the product will not be exactly the same, there will be differences in color and drawing.', 100),
('KEY3', 'Shin keychain', 'KCT1', 20, 'key-3.jpg', 'Cute keychain for Shin wearing a shirt, used as a gift for hanging backpacks and bags, high quality PVC material', 100),
('OFFICE1', 'Pen jar with engraved name', 'OET1', 200, 'decor-1.jpg', 'The product is made from smooth wood, can be engraved with letters or patterns on both the tube and base tray, suitable as a gift to decorate desks, study tables, etc.', 20),
('OFFICE2', 'Wooden Ruler With Engraved Name', 'OET1', 10, 'office-2.jpg', 'The ruler is made from natural wood, lightly painted with PU paint to increase durability, clearly printed with graduation lines and numbers, and highly accurate.', 100),
('OFFICE3', 'High quality pen holder', 'OET1', 1000, 'office-3.jpg', 'The box is delicately designed, the inside is designed in yellow to create a luxurious feeling, making the pen contained inside become more premium. Create a difference for the gift, making the pen more valuable.', 20),
('SAVINGTUBE2', 'HOUSE SHAPE PINK BLUE MONEY SAVING BOX', 'SAVT1', 120000, 'pig-2.jpg', 'Made of durable, rough plastic, not the thin, reprocessable type, with a small lid that can be opened for reuse forever.', 1000),
('SAVINGTUBE3', 'Glass piggy bank', 'SAVT1', 230, 'pig-3.jpg', 'Mini glass pig containing lucky gold', 100),
('TOY1', 'Secret gift charm candy', 'TOY1', 100, 'toy-1.jpg', 'Charm candy secret gift, mini blind bag to test dignity blindbox, surprise gift bag with many cute pictures, student gift', 50),
('TOY2', 'Teddy Bear Stuffed Wolf Dog', 'TOY1', 200, 'toy-2.jpg', 'Teddy Bear Stuffed Wolf Dog Cute Decorative Gift Birthday holiday gift good price', 50),
('TOY3', 'Omamori Genshin Impact Lucky Bag', 'TOY1', 5000, 'toy-3.jpg', 'Omamori Genshin Impact Lucky Bag Acrylic Material Gift Souvenirs Backpack Decoration Kazuha Hutao Ayaka, Klee', 1000);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account`
--
ALTER TABLE `account`
  ADD PRIMARY KEY (`acc_id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`cate_id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`contact_id`);

--
-- Indexes for table `order_info`
--
ALTER TABLE `order_info`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `order_products`
--
ALTER TABLE `order_products`
  ADD PRIMARY KEY (`order_id`,`prod_id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`prod_id`),
  ADD KEY `FK_cate_id` (`cate_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `account`
--
ALTER TABLE `account`
  MODIFY `acc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `contact_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `order_info`
--
ALTER TABLE `order_info`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `FK_cate_id` FOREIGN KEY (`cate_id`) REFERENCES `category` (`cate_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
