<?php
    include 'connect.php';

    class account {
        static public function users($username) {
            global $conn;

            $sql = "SELECT * FROM account WHERE acc_username = '$username'";

            return mysqli_query($conn, $sql);
        }

        static public function signup($username, $password, $email, $role) {
            global $conn;

            $sql = "INSERT INTO account(acc_username, acc_password, email, acc_role) VALUES('$username', '$password', '$email', '$role')";

            return mysqli_query($conn, $sql);
        }

        static public function get_all() {
            global $conn;

            $sql = "SELECT * FROM account";

            return mysqli_query($conn, $sql);
        }       

        static public function get_acc($id) {
            global $conn;

            $sql = "SELECT * FROM account WHERE acc_id = '$id'";

            return mysqli_query($conn, $sql);
        }

        static public function get_password($email) {
            global $conn;

            $sql = "SELECT acc_password FROM account WHERE email = '$email'";

            return mysqli_query($conn, $sql);
        }

        static public function update($id, $username, $password, $email) {
            global $conn;

            $sql = "UPDATE account SET acc_username = '$username', acc_password = '$password', email = '$email' WHERE acc_id = '$id'";

            return mysqli_query($conn, $sql);
        }

        static public function delete($id) {
            global $conn;

            $sql = "DELETE FROM account WHERE acc_id = '$id'";

            return mysqli_query($conn, $sql);
        }

        static public function get_orders($acc_id) {
            global $conn;

            $sql = "
                SELECT * FROM order_info 
                INNER JOIN order_products ON order_info.order_id = order_products.order_id 
                INNER JOIN product ON product.prod_id = order_products.prod_id 
                WHERE order_info.acc_id = '$acc_id' 
                ORDER BY order_info.order_id DESC;              
            ";

            $result = mysqli_query($conn, $sql);
            $orders = array();
            
            foreach($result as $item) {
                if(!array_key_exists($item["order_id"], $orders)) {
                    $orders += [$item["order_id"] => array(
                        "info" => array(
                            "order_date"      => $item["order_date"], 
                            "into_money"      => $item["into_money"], 
                            "shipping_status" => $item["shipping_status"]
                        ),

                        "products" => array(array(                           
                            "prod_id"          => $item["prod_id"], 
                            "prod_title"       => $item["prod_title"], 
                            "price"            => $item["price"], 
                            "picture"          => $item["picture"], 
                            "prod_description" => $item["prod_description"], 
                            "quantity"         => $item["quantity"]
                        ))
                    )];
                }
                else {
                    array_push($orders[$item["order_id"]]["products"], array(                           
                        "prod_id"          => $item["prod_id"], 
                        "prod_title"       => $item["prod_title"], 
                        "price"            => $item["price"], 
                        "picture"          => $item["picture"], 
                        "prod_description" => $item["prod_description"], 
                        "quantity"         => $item["quantity"]
                    ));
                }
            }

            return $orders;
        }
    }

    class category {
        static public function add($cate_id, $cate_name) {
            global $conn;

            $sql = "INSERT INTO category VALUES('$cate_id','$cate_name')";

            return mysqli_query($conn, $sql);
        }

        static public function get_all() {
            global $conn;

            $sql = "SELECT * FROM category";

            return mysqli_query($conn, $sql);
        }

        static public function delete($id) {
            global $conn;

            $sql = "DELETE FROM category WHERE cate_id = '$id'";

            return mysqli_query($conn, $sql);
        }

        static public function update($id, $new_name) {
            global $conn;

            $sql = "UPDATE category SET cate_name = '$new_name' WHERE cate_id = '$id'";

            return mysqli_query($conn, $sql);
        }

        static public function get_cate($id) {
            global $conn;

            $sql = "SELECT * FROM category WHERE cate_id = '$id'";

            return mysqli_query($conn, $sql);
        }
    }

    class contact {
        static public function add($sender_name, $sender_email, $message) {
            global $conn;

            $sql = "INSERT INTO contact(sender_name,sender_email, message) VALUES('$sender_name', '$sender_email', '$message')";

            return mysqli_query($conn, $sql);
        }

        static public function get_all() {
            global $conn;

            $sql = "SELECT * FROM contact";

            return mysqli_query($conn, $sql);
        }

        static public function delete($id) {
            global $conn;

            $sql = "DELETE FROM contact WHERE contact_id = '$id'";

            return mysqli_query($conn, $sql);
        }

        static public function get_contact($id) {
            global $conn;

            $sql = "SELECT * FROM contact WHERE contact_id = '$id'";

            return mysqli_query($conn, $sql);
        }        
    }

    class product {
        static public function add($prod_id, $prod_title, $cate_id, $price, $picture, $prod_description, $inventory) {
            global $conn;

            $sql = "INSERT INTO product VALUES('$prod_id', '$prod_title', '$cate_id', '$price', '$picture', '$prod_description', '$inventory')";

            return mysqli_query($conn, $sql);
        }

        static public function get_all() {
            global $conn;

            $sql = "SELECT * FROM product INNER JOIN category ON product.cate_id = category.cate_id";

            return mysqli_query($conn, $sql);
        }

        static public function delete($id) {
            global $conn;

            $sql = "DELETE FROM product WHERE prod_id = '$id'";

            return mysqli_query($conn, $sql);
        }

        static public function update($prod_id, $prod_title, $cate_id, $price, $picture, $prod_description, $inventory) {
            global $conn;

            $sql = "UPDATE product SET prod_title = '$prod_title', cate_id = '$cate_id', price = $price, picture = '$picture', prod_description = '$prod_description', inventory = $inventory WHERE prod_id = '$prod_id'";

            return mysqli_query($conn, $sql);
        }

        static public function get_prod($id) {
            global $conn;

            $sql = "SELECT * FROM product INNER JOIN category ON product.cate_id = category.cate_id WHERE prod_id = '$id'";

            return mysqli_query($conn, $sql);
        } 
        
        static public function get_by_cate($cate_id) {
            global $conn;

            $sql = "SELECT * FROM product INNER JOIN category ON product.cate_id = category.cate_id WHERE category.cate_id = '$cate_id'";

            return mysqli_query($conn, $sql);            
        }

        static public function get_by_name($name) {
            global $conn;

            $sql = "SELECT * FROM product INNER JOIN category ON product.cate_id = category.cate_id WHERE product.prod_title LIKE '%$name%'";

            return mysqli_query($conn, $sql);             
        }

        static public function related_prods($prod_id, $cate_id) {
            global $conn;

            $sql = "SELECT * FROM product INNER JOIN category ON product.cate_id = category.cate_id WHERE category.cate_id = '$cate_id' AND prod_id != '$prod_id'";

            return mysqli_query($conn, $sql);            
        }
    }

    class order {
        static public function add($acc_id, $into_money, array $cart) {
            global $conn;
            
            $sql = "INSERT INTO order_info(acc_id,order_date,into_money,shipping_status) VALUES('$acc_id', CURRENT_TIMESTAMP(), '$into_money', 'waiting for confirmation')";

            $success = mysqli_query($conn, $sql); 

            if($success) {
                $last_order_id = $conn->insert_id;
                $sql = "INSERT INTO order_products VALUES ";
                foreach($cart as $key => $item) {
                    $quantity = $item['quantity'];
                    $sql .= "('$last_order_id','$key', $quantity),";
                }

                $sql[strlen($sql) - 1] = ';';
                $success = mysqli_query($conn, $sql); 

                return $success;
            }
            
            return false;
        }

        static public function get_all() {
            global $conn;

            $sql = "SELECT * FROM order_info";

            return mysqli_query($conn, $sql);
        }  
        
        static public function get_order($order_id) {
            global $conn;

            $sql = "SELECT * FROM order_info WHERE order_id = '$order_id'";

            return mysqli_query($conn, $sql);            
        }

        static public function get_products($order_id) {
            global $conn;

            $sql = "SELECT * FROM order_products INNER JOIN product ON order_products.prod_id = product.prod_id WHERE order_id = '$order_id'";

            return mysqli_query($conn, $sql);            
        }

        static public function update_ship_stt($order_id, $stt) {
            global $conn;

            $sql = "UPDATE order_info SET shipping_status = '$stt' WHERE order_id = '$order_id'";

            return mysqli_query($conn, $sql);             
        }
    }

    class report {
        static public function revenue() {
            global $conn;

            $sql = "SELECT SUM(into_money) AS total FROM order_info";

            return mysqli_query($conn, $sql)->fetch_assoc()["total"];
        }

        static public function order_count() {
            global $conn;

            $sql = "SELECT COUNT(*) AS order_count FROM order_info";

            return mysqli_query($conn, $sql)->fetch_assoc()["order_count"];
        }

        static public function client_count() {
            global $conn;

            $sql = "SELECT COUNT(*) AS client_count FROM account WHERE account.acc_id IN (SELECT order_info.acc_id FROM order_info) AND account.acc_role = 'user';";

            return mysqli_query($conn, $sql)->fetch_assoc()["client_count"];
        }

        static public function year_chart_data() {
            global $conn;

            $sql = "SELECT YEAR(order_info.order_date) AS order_year, COUNT(*) AS order_count, SUM(order_info.into_money) / 1000 AS revenue FROM order_info GROUP BY YEAR(order_info.order_date);";

            $result = mysqli_query($conn, $sql);
            $data = array();

            foreach ($result as $item) {
                $data += [$item["order_year"] => array(
                    "order_count" => $item["order_count"], 
                    "revenue" => $item["revenue"]
                )];
            }

            return $data;             
        }
    }



