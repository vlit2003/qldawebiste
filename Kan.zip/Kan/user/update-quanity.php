<?php 
    session_start();

    $_SESSION["cart"][$_GET["k"]]["quantity"] = $_GET["nq"];
    echo "<script> window.location = 'cart.php'; </script>";       