<?php 
    include '../src/controls.php';
    session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Kan Store</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="assets/img/kkkk.jpg">
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/kkkk.jpg">

    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/templatemo.css">
    <link rel="stylesheet" href="assets/css/custom.css">

    <!-- Load fonts style after rendering the layout styles -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;200;300;400;500;700;900&display=swap">
    <link rel="stylesheet" href="assets/css/fontawesome.min.css">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" hrel="assets/css/profile.css">
<!--
    
TemplateMo 559 Zay Shop

https://templatemo.com/tm-559-zay-shop

-->
<style>
        body{
    background:#f9f9fb;    
    }
    .view-account{
    background:#FFFFFF; 
    margin-top:20px;
    }
    .view-account .pro-label {
    font-size: 13px;
    padding: 4px 5px;
    position: relative;
    top: -5px;
    margin-left: 10px;
    display: inline-block
    }
    
    .view-account .side-bar {
    padding-bottom: 30px
    }
    
    .view-account .side-bar .user-info {
    text-align: center;
    margin-bottom: 15px;
    padding: 30px;
    color: #616670;
    border-bottom: 1px solid #f3f3f3
    }
    
    .view-account .side-bar .user-info .img-profile {
    width: 120px;
    height: 120px;
    margin-bottom: 15px
    }
    
    .view-account .side-bar .user-info .meta li {
    margin-bottom: 10px
    }
    
    .view-account .side-bar .user-info .meta li span {
    display: inline-block;
    width: 100px;
    margin-right: 5px;
    text-align: right
    }
    
    .view-account .side-bar .user-info .meta li a {
    color: #616670
    }
    
    .view-account .side-bar .user-info .meta li.activity {
    color: #a2a6af
    }
    
    .view-account .side-bar .side-menu {
    text-align: center
    }
    
    .view-account .side-bar .side-menu .nav {
    display: inline-block;
    margin: 0 auto
    }
    
    .view-account .side-bar .side-menu .nav>li {
    font-size: 14px;
    margin-bottom: 0;
    border-bottom: none;
    display: inline-block;
    float: left;
    margin-right: 15px;
    margin-bottom: 15px
    }
    
    .view-account .side-bar .side-menu .nav>li:last-child {
    margin-right: 0
    }
    
    .view-account .side-bar .side-menu .nav>li>a {
    display: inline-block;
    color: #9499a3;
    padding: 5px;
    border-bottom: 2px solid transparent
    }
    
    .view-account .side-bar .side-menu .nav>li>a:hover {
    color: #616670;
    background: none
    }

    .view-account .side-bar .side-menu .nav>li.active a {
    color: #69bb7e; 
    border-bottom: 2px solid #69bb7e;
    background: none;
    border-right: none; 
    }
    
    .theme-2 .view-account .side-bar .side-menu .nav>li.active a {
    color: #6dbd63;
    border-bottom-color: #6dbd63
    }
    
    .theme-3 .view-account .side-bar .side-menu .nav>li.active a {
    color: #497cb1;
    border-bottom-color: #497cb1
    }
    
    .theme-4 .view-account .side-bar .side-menu .nav>li.active a {
    color: #ec6952;
    border-bottom-color: #ec6952
    }
    
    .view-account .side-bar .side-menu .nav>li .icon {
    display: block;
    font-size: 24px;
    margin-bottom: 5px
    }
    
    .view-account .content-panel {
    padding: 30px
    }
    
    .view-account .content-panel .title {
    margin-bottom: 15px;
    margin-top: 0;
    font-size: 18px
    }
    
    .view-account .content-panel .fieldset-title {
    padding-bottom: 15px;
    border-bottom: 1px solid #eaeaf1;
    margin-bottom: 30px;
    color: #616670;
    font-size: 16px
    }
    
    .view-account .content-panel .avatar .figure img {
    float: right;
    width: 64px
    }
    
    .view-account .content-panel .content-header-wrapper {
    position: relative;
    margin-bottom: 30px
    }
    
    .view-account .content-panel .content-header-wrapper .actions {
    position: absolute;
    right: 0;
    top: 0
    }
    
    .view-account .content-panel .content-utilities {
    position: relative;
    margin-bottom: 30px
    }
    
    .view-account .content-panel .content-utilities .btn-group {
    margin-right: 5px;
    margin-bottom: 15px
    }
    
    .view-account .content-panel .content-utilities .fa {
    font-size: 16px;
    margin-right: 0
    }
    
    .view-account .content-panel .content-utilities .page-nav {
    position: absolute;
    right: 0;
    top: 0
    }
    
    .view-account .content-panel .content-utilities .page-nav .btn-group {
    margin-bottom: 0
    }
    
    .view-account .content-panel .content-utilities .page-nav .indicator {
    color: #a2a6af;
    margin-right: 5px;
    display: inline-block
    }
    
    .view-account .content-panel .mails-wrapper .mail-item {
    position: relative;
    padding: 10px;
    border-bottom: 1px solid #f3f3f3;
    color: #616670;
    overflow: hidden
    }
    
    .view-account .content-panel .mails-wrapper .mail-item>div {
    float: left
    }
    
    .view-account .content-panel .mails-wrapper .mail-item .icheck {
    background-color: #fff
    }
    
    .view-account .content-panel .mails-wrapper .mail-item:hover {
    background: #f9f9fb
    }
    
    .view-account .content-panel .mails-wrapper .mail-item:nth-child(even) {
    background: #fcfcfd
    }
    
    .view-account .content-panel .mails-wrapper .mail-item:nth-child(even):hover {
    background: #f9f9fb
    }
    
    .view-account .content-panel .mails-wrapper .mail-item a {
    color: #616670
    }
    
    .view-account .content-panel .mails-wrapper .mail-item a:hover {
    color: #494d55;
    text-decoration: none
    }
    
    .view-account .content-panel .mails-wrapper .mail-item .checkbox-container,
    .view-account .content-panel .mails-wrapper .mail-item .star-container {
    display: inline-block;
    margin-right: 5px
    }
    
    .view-account .content-panel .mails-wrapper .mail-item .star-container .fa {
    color: #a2a6af;
    font-size: 16px;
    vertical-align: middle
    }
    
    .view-account .content-panel .mails-wrapper .mail-item .star-container .fa.fa-star {
    color: #f2b542
    }
    
    .view-account .content-panel .mails-wrapper .mail-item .star-container .fa:hover {
    color: #868c97
    }
    
    .view-account .content-panel .mails-wrapper .mail-item .mail-to {
    display: inline-block;
    margin-right: 5px;
    min-width: 120px
    }
    
    .view-account .content-panel .mails-wrapper .mail-item .mail-subject {
    display: inline-block;
    margin-right: 5px
    }
    
    .view-account .content-panel .mails-wrapper .mail-item .mail-subject .label {
    margin-right: 5px
    }
    
    .view-account .content-panel .mails-wrapper .mail-item .mail-subject .label:last-child {
    margin-right: 10px
    }
    
    .view-account .content-panel .mails-wrapper .mail-item .mail-subject .label a,
    .view-account .content-panel .mails-wrapper .mail-item .mail-subject .label a:hover {
    color: #fff
    }
    
    .view-account .content-panel .mails-wrapper .mail-item .mail-subject .label-color-1 {
    background: #f77b6b
    }
    
    .view-account .content-panel .mails-wrapper .mail-item .mail-subject .label-color-2 {
    background: #58bbee
    }
    
    .view-account .content-panel .mails-wrapper .mail-item .mail-subject .label-color-3 {
    background: #f8a13f
    }
    
    .view-account .content-panel .mails-wrapper .mail-item .mail-subject .label-color-4 {
    background: #ea5395
    }
    
    .view-account .content-panel .mails-wrapper .mail-item .mail-subject .label-color-5 {
    background: #8a40a7
    }
    
    .view-account .content-panel .mails-wrapper .mail-item .time-container {
    display: inline-block;
    position: absolute;
    right: 10px;
    top: 10px;
    color: #a2a6af;
    text-align: left
    }
    
    .view-account .content-panel .mails-wrapper .mail-item .time-container .attachment-container {
    display: inline-block;
    color: #a2a6af;
    margin-right: 5px
    }
    
    .view-account .content-panel .mails-wrapper .mail-item .time-container .time {
    display: inline-block;
    text-align: right
    }
    
    .view-account .content-panel .mails-wrapper .mail-item .time-container .time.today {
    font-weight: 700;
    color: #494d55
    }
    
    .drive-wrapper {
    padding: 15px;
    background: #f5f5f5;
    overflow: hidden
    }
    
    .drive-wrapper .drive-item {
    width: 130px;
    margin-right: 15px;
    display: inline-block;
    float: left;
    }
    
    .drive-wrapper .drive-item:hover {
    box-shadow: 0 1px 5px rgba(0, 0, 0, .1);
    z-index: 1
    }
    
    .drive-wrapper .drive-item-inner {
    padding: 15px
    }
    
    .drive-wrapper .drive-item-title {
    margin-bottom: 15px;
    max-width: 100px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis
    }
    
    .drive-wrapper .drive-item-title a {
    color: #494d55
    }
    
    .drive-wrapper .drive-item-title a:hover {
    color: #40babd
    }
    
    .theme-2 .drive-wrapper .drive-item-title a:hover {
    color: #6dbd63
    }
    
    .theme-3 .drive-wrapper .drive-item-title a:hover {
    color: #497cb1
    }
    
    .theme-4 .drive-wrapper .drive-item-title a:hover {
    color: #ec6952
    }
    
    .drive-wrapper .drive-item-thumb {
    width: 100px;
    height: 80px;
    margin: 0 auto;
    color: #616670
    }
    
    .drive-wrapper .drive-item-thumb a {
    -webkit-opacity: .8;
    -moz-opacity: .8;
    opacity: .8
    }
    
    .drive-wrapper .drive-item-thumb a:hover {
    -webkit-opacity: 1;
    -moz-opacity: 1;
    opacity: 1
    }
    
    .drive-wrapper .drive-item-thumb .fa {
    display: inline-block;
    font-size: 36px;
    margin: 0 auto;
    margin-top: 20px
    }
    
    .drive-wrapper .drive-item-footer .utilities {
    margin-bottom: 0
    }
    
    .drive-wrapper .drive-item-footer .utilities li:last-child {
    padding-right: 0
    }
    
    .drive-list-view .name {
    width: 60%
    }
    
    .drive-list-view .name.truncate {
    max-width: 100px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis
    }
    
    .drive-list-view .type {
    width: 15px
    }
    
    .drive-list-view .date,
    .drive-list-view .size {
    max-width: 60px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis
    }
    
    .drive-list-view a {
    color: #494d55
    }
    
    .drive-list-view a:hover {
    color: #40babd
    }
    
    .theme-2 .drive-list-view a:hover {
    color: #6dbd63
    }
    
    .theme-3 .drive-list-view a:hover {
    color: #497cb1
    }
    
    .theme-4 .drive-list-view a:hover {
    color: #ec6952
    }
    
    .drive-list-view td.date,
    .drive-list-view td.size {
    color: #a2a6af
    }
    
    @media (max-width:767px) {
    .view-account .content-panel .title {
        text-align: center
    }
    .view-account .side-bar .user-info {
        padding: 0
    }
    .view-account .side-bar .user-info .img-profile {
        width: 60px;
        height: 60px
    }
    .view-account .side-bar .user-info .meta li {
        margin-bottom: 5px
    }
    .view-account .content-panel .content-header-wrapper .actions {
        position: static;
        margin-bottom: 30px
    }
    .view-account .content-panel {
        padding: 0
    }
    .view-account .content-panel .content-utilities .page-nav {
        position: static;
        margin-bottom: 15px
    }
    .drive-wrapper .drive-item {
        width: 100px;
        margin-right: 5px;
        float: none
    }
    .drive-wrapper .drive-item-thumb {
        width: auto;
        height: 54px
    }
    .drive-wrapper .drive-item-thumb .fa {
        font-size: 24px;
        padding-top: 0
    }
    .view-account .content-panel .avatar .figure img {
        float: none;
        margin-bottom: 15px
    }
    .view-account .file-uploader {
        margin-bottom: 15px
    }
    .view-account .mail-subject {
        max-width: 100px;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis
    }
    .view-account .content-panel .mails-wrapper .mail-item .time-container {
        position: static
    }
    .view-account .content-panel .mails-wrapper .mail-item .time-container .time {
        width: auto;
        text-align: left
    }
    }
    
    @media (min-width:768px) {
    .view-account .side-bar .user-info {
        padding: 0;
        padding-bottom: 15px
    }
    .view-account .mail-subject .subject {
        max-width: 200px;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis
    }
    }
    
    @media (min-width:992px) {
    .view-account .content-panel {
        min-height: 800px;
        border-left: 1px solid #f3f3f7;
        margin-left: 200px
    }
    .view-account .mail-subject .subject {
        max-width: 280px;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis
    }
    .view-account .side-bar {
        position: absolute;
        width: 200px;
        min-height: 600px
    }
    .view-account .side-bar .user-info {
        margin-bottom: 0;
        border-bottom: none;
        padding: 30px
    }
    .view-account .side-bar .user-info .img-profile {
        width: 120px;
        height: 120px
    }
    .view-account .side-bar .side-menu {
        text-align: left
    }
    .view-account .side-bar .side-menu .nav {
        display: block
    }
    .view-account .side-bar .side-menu .nav>li {
        display: block;
        float: none;
        font-size: 14px;
        border-bottom: 1px solid #f3f3f7;
        margin-right: 0;
        margin-bottom: 0
    }
    .view-account .side-bar .side-menu .nav>li>a {
        display: block;
        color: #9499a3;
        padding: 10px 15px;
        padding-left: 30px
    }
    .view-account .side-bar .side-menu .nav>li>a:hover {
        background: #f9f9fb
    }
    .view-account .side-bar .side-menu .nav>li.active a {
        background: #f9f9fb;
        border-right: 4px solid #69bb7e;
        border-bottom: none
    }
    .theme-2 .view-account .side-bar .side-menu .nav>li.active a {
        border-right-color: #6dbd63
    }
    .theme-3 .view-account .side-bar .side-menu .nav>li.active a {
        border-right-color: #497cb1
    }
    .theme-4 .view-account .side-bar .side-menu .nav>li.active a {
        border-right-color: #ec6952
    }
    .view-account .side-bar .side-menu .nav>li .icon {
        font-size: 24px;
        vertical-align: middle;
        text-align: center;
        width: 40px;
        display: inline-block
    }
}
</style>

<style>
    .logout a {
        color: #616670;
    }

    .logout a:hover {
        color: #69bb7e;
    }
</style>
</head>

<body>
    <!-- Start Top Nav -->
    <nav class="navbar navbar-expand-lg bg-dark navbar-light d-none d-lg-block" id="templatemo_nav_top">
        <div class="container text-light">
            <div class="w-100 d-flex justify-content-between">
                <div>
                    <i class="fa fa-envelope mx-2"></i>
                    <a class="navbar-sm-brand text-light text-decoration-none" href="mailto:info@company.com">kantran09082003@gmail.com</a>
                    <i class="fa fa-phone mx-2"></i>
                    <a class="navbar-sm-brand text-light text-decoration-none" href="tel:010-020-0340">0396588768</a>
                </div>
                <div>
                    <a class="text-light" href="https://fb.com/templatemo" target="_blank" rel="sponsored"><i class="fab fa-facebook-f fa-sm fa-fw me-2"></i></a>
                    <a class="text-light" href="https://www.instagram.com/" target="_blank"><i class="fab fa-instagram fa-sm fa-fw me-2"></i></a>
                    <a class="text-light" href="https://twitter.com/" target="_blank"><i class="fab fa-twitter fa-sm fa-fw me-2"></i></a>
                    <a class="text-light" href="https://www.linkedin.com/" target="_blank"><i class="fab fa-linkedin fa-sm fa-fw"></i></a>
                </div>
            </div>
        </div>
    </nav>
    <!-- Close Top Nav -->


    <!-- Header -->
    <nav class="navbar navbar-expand-lg navbar-light shadow">
        <div class="container d-flex justify-content-between align-items-center">
            <a class="navbar-brand text-success logo h1 align-self-center" href="index.php">
                Kan
            </a>

            <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#templatemo_main_nav" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="align-self-center collapse navbar-collapse flex-fill  d-lg-flex justify-content-lg-between" id="templatemo_main_nav">
                <div class="flex-fill">
                    <ul class="nav navbar-nav d-flex justify-content-between mx-lg-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="index.php">Trang Chủ </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="about.php">Về chúng tôi</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="shop.php">Cửa hàng nhà Kan</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="contact.php">Liên Hệ</a>
                        </li>
                    </ul>
                </div>
                <div class="navbar align-self-center d-flex">
                    <div class="d-lg-none flex-sm-fill mt-3 mb-4 col-7 col-sm-auto pr-3">
                        <div class="input-group">
                            <input type="text" class="form-control" id="inputMobileSearch" placeholder="Search ...">
                            <div class="input-group-text">
                                <i class="fa fa-fw fa-search"></i>
                            </div>
                        </div>
                    </div>
                    <a class="nav-icon d-none d-lg-inline" href="#" data-bs-toggle="modal" data-bs-target="#templatemo_search">
                        <i class="fa fa-fw fa-search text-dark mr-2"></i>
                    </a>

                    <?php 
                        if(isset($_SESSION["username"])) { ?>
                            <a class="nav-icon position-relative text-decoration-none" href="cart.php"> <!-- Cart -->
                                <i class="fa fa-fw fa-cart-arrow-down text-dark mr-1"></i>
                                <span class="position-absolute top-0 left-100 translate-middle badge rounded-pill bg-light text-dark">
                                    <?php 
                                        if(isset($_SESSION["cart"])) {
                                            echo count($_SESSION["cart"]);
                                        } else {
                                            echo "0";
                                        }
                                    ?>
                                </span>
                            </a>
                            <a class="nav-icon position-relative text-decoration-none" href="profile.php">  <!-- Account -->
                                <i class="fa fa-fw fa-user text-dark mr-3"></i>
                            </a> <?php 
                        } else { ?> 
                            <a href="../login/login-signup.php" style="text-decoration: none; font-weight: bold;"> Đăng Nhập / Đăng Ký </a> <?php 
                        }
                    ?>
                </div>
            </div>
        </div>
    </nav>
    <!-- Close Header -->

    <!-- Modal -->
    <div class="modal fade bg-white" id="templatemo_search" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="w-100 pt-1 mb-5 text-right">
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="search-result.php" method="get" class="modal-content modal-body border-0 p-0">
                <div class="input-group mb-2">
                    <input type="text" class="form-control" id="inputModalSearch" name="q" placeholder="Put name product here ...">
                    <button type="submit" class="input-group-text bg-success text-light">
                        <i class="fa fa-fw fa-search text-white"></i>
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Start Content -->
    <div class="container py-5">
        <div class="row">
            <div class="container">
                <div class="view-account">
                    <section class="module">
                        <div class="module-inner">
                            <div class="side-bar">
                        		<nav class="side-menu">
                    				<ul class="nav">
                    					<li class="active"><a href="profile.php" style="text-decoration: none;"><span class="fa fa-user"></span>&nbsp;&nbsp;&nbsp;Tài khoản</a></li>
                    					<li><a href="order.php" style="text-decoration: none;"><span class="fa fa-truck"></span>&nbsp;&nbsp;Đặt hàng</a></li>
                                        <?php 
                                            if($_SESSION["role"] == "admin") { ?>
                                                <li><a href="../admin/dashboard.php" style="text-decoration: none;"><span class="fa fa-desktop"></span>&nbsp;&nbsp;Quản trị viên</a></li> <?php 
                                            } 
                                        ?>
                    				</ul>

                                    <div class="logout" style="margin-left: 30px; margin-top: 30px;">
                                        <a href="logout.php" style="text-decoration: none;"><i class="fa fa-sign-out"></i>&nbsp;&nbsp;Đăng xuất</a>
                                    </div>
                    			</nav>
                            </div>
                            <div class="content-panel">
                                <?php 
                                    $account = account::get_acc($_SESSION["acc_id"])->fetch_assoc();
                                ?>
            
                                <form method="post" class="form-horizontal">
                                    <fieldset class="fieldset">
                                        <h3 class="fieldset-title">Thông tin tài khoản</h3>
                                        <div class="form-group">
                                            <label class="col-md-2 col-sm-3 col-xs-12 control-label" style="margin-bottom: 10px;">Tên tài khoản</label>
                                            <div class="col-md-10 col-sm-9 col-xs-12">
                                                <input type="text" class="form-control" name="username" value="<?php echo $account["acc_username"] ?>">
                                            </div>
                                        </div>
                                        <div style="height: 30px;"></div>
                                        <div class="form-group">
                                            <label class="col-md-2 col-sm-3 col-xs-12 control-label" style="margin-bottom: 10px;">Mật Khẩu</label>
                                            <div class="col-md-10 col-sm-9 col-xs-12">
                                                <input type="text" class="form-control" name="password" value="<?php echo $account["acc_password"] ?>">
                                            </div>
                                        </div>
                                    </fieldset>
                                    <fieldset class="fieldset" style="margin-top: 30px;">
                                        <h3 class="fieldset-title">Thông tin liên lạc</h3>
                                        <div class="form-group">
                                            <label class="col-md-2  col-sm-3 col-xs-12 control-label" style="margin-bottom: 10px;">Email</label>
                                            <div class="col-md-10 col-sm-9 col-xs-12">
                                                <input type="email" class="form-control" name="email" value="<?php echo $account["email"] ?>">
                                            </div>
                                        </div>
                                    </fieldset>
                                    <hr>
                                    <div class="form-group">
                                        <div class="col-md-10 col-sm-9 col-xs-12 col-md-push-2 col-sm-push-3 col-xs-push-0">
                                            <input class="btn btn-primary" name="update-submit" type="submit" value="Update">
                                        </div>
                                    </div>
                                </form>
            
                                <?php 
                                    if(isset($_POST["update-submit"])) {
                                        if(account::update($_SESSION["acc_id"], $_POST["username"], $_POST["password"], $_POST["email"])) {
                                            $_SESSION["username"] = $_POST["username"];
                                            echo "<script> alert('Update account success!') </script>";
                                            echo "<script> window.location = 'profile.php' </script>";
                                        }
                                    }
                                ?>
                            </div>
                        </div>
                    </section>
                </div>
            </div>
        </div>
    </div>
    <!-- End Content -->

    <!-- Start Brands -->
    <section class="bg-light py-5">
        <div class="container my-4">
            <div class="row text-center py-3">
                <div class="col-lg-6 m-auto">
                    <h1 class="h1">Thương hiệu</h1>
                </div>
                <div class="col-lg-9 m-auto tempaltemo-carousel">
                    <div class="row d-flex flex-row">
                        <!--Controls-->
                        <div class="col-1 align-self-center">
                            <a class="h1" href="#multi-item-example" role="button" data-bs-slide="prev">
                                <i class="text-light fas fa-chevron-left"></i>
                            </a>
                        </div>
                        <!--End Controls-->

                        <!--Carousel Wrapper-->
                        <div class="col">
                            <div class="carousel slide carousel-multi-item pt-2 pt-md-0" id="multi-item-example" data-bs-ride="carousel">
                                <!--Slides-->
                                <div class="carousel-inner product-links-wap" role="listbox">

                                    <!--First slide-->
                                    <div class="carousel-item active">
                                        <div class="row">
                                            <div class="col-3 p-md-5">
                                                <a href="#"><img class="img-fluid brand-img" src="assets/img/brand_01.png" alt="Brand Logo"></a>
                                            </div>
                                            <div class="col-3 p-md-5">
                                                <a href="#"><img class="img-fluid brand-img" src="assets/img/brand_02.png" alt="Brand Logo"></a>
                                            </div>
                                            <div class="col-3 p-md-5">
                                                <a href="#"><img class="img-fluid brand-img" src="assets/img/brand_03.png" alt="Brand Logo"></a>
                                            </div>
                                            <div class="col-3 p-md-5">
                                                <a href="#"><img class="img-fluid brand-img" src="assets/img/brand_04.png" alt="Brand Logo"></a>
                                            </div>
                                        </div>
                                    </div>
                                    <!--End First slide-->

                                    <!--Second slide-->
                                    <div class="carousel-item">
                                        <div class="row">
                                            <div class="col-3 p-md-5">
                                                <a href="#"><img class="img-fluid brand-img" src="assets/img/brand_01.png" alt="Brand Logo"></a>
                                            </div>
                                            <div class="col-3 p-md-5">
                                                <a href="#"><img class="img-fluid brand-img" src="assets/img/brand_02.png" alt="Brand Logo"></a>
                                            </div>
                                            <div class="col-3 p-md-5">
                                                <a href="#"><img class="img-fluid brand-img" src="assets/img/brand_03.png" alt="Brand Logo"></a>
                                            </div>
                                            <div class="col-3 p-md-5">
                                                <a href="#"><img class="img-fluid brand-img" src="assets/img/brand_04.png" alt="Brand Logo"></a>
                                            </div>
                                        </div>
                                    </div>
                                    <!--End Second slide-->

                                    <!--Third slide-->
                                    <div class="carousel-item">
                                        <div class="row">
                                            <div class="col-3 p-md-5">
                                                <a href="#"><img class="img-fluid brand-img" src="assets/img/brand_01.png" alt="Brand Logo"></a>
                                            </div>
                                            <div class="col-3 p-md-5">
                                                <a href="#"><img class="img-fluid brand-img" src="assets/img/brand_02.png" alt="Brand Logo"></a>
                                            </div>
                                            <div class="col-3 p-md-5">
                                                <a href="#"><img class="img-fluid brand-img" src="assets/img/brand_03.png" alt="Brand Logo"></a>
                                            </div>
                                            <div class="col-3 p-md-5">
                                                <a href="#"><img class="img-fluid brand-img" src="assets/img/brand_04.png" alt="Brand Logo"></a>
                                            </div>
                                        </div>
                                    </div>
                                    <!--End Third slide-->

                                </div>
                                <!--End Slides-->
                            </div>
                        </div>
                        <!--End Carousel Wrapper-->

                        <!--Controls-->
                        <div class="col-1 align-self-center">
                            <a class="h1" href="#multi-item-example" role="button" data-bs-slide="next">
                                <i class="text-light fas fa-chevron-right"></i>
                            </a>
                        </div>
                        <!--End Controls-->
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End Brands-->


    <!-- Start Footer -->
    <footer class="bg-dark" id="tempaltemo_footer">
        <div class="container">
            <div class="row">

                <div class="col-md-4 pt-5">
                    <h2 class="h2 text-success border-bottom pb-3 border-light logo">Kan Store</h2>
                    <ul class="list-unstyled text-light footer-link-list">
                        <li>
                            <i class="fas fa-map-marker-alt fa-fw"></i>
                            250 Minh Khai - Hai Bà Trưng - Hà Nội
                        </li>
                        <li>
                            <i class="fa fa-phone fa-fw"></i>
                            <a class="text-decoration-none" href="tel:010-020-0340">0396588768</a>
                        </li>
                        <li>
                            <i class="fa fa-envelope fa-fw"></i>
                            <a class="text-decoration-none" href="mailto:info@company.com">kantran0396588768@gmail.com</a>
                        </li>
                    </ul>
                </div>

                <div class="col-md-4 pt-5">
                    <h2 class="h2 text-light border-bottom pb-3 border-light">Các Danh Mục Sản Phẩm </h2>
                    <ul class="list-unstyled text-light footer-link-list">
                        <?php 
                            $categories = category::get_all();
                            foreach($categories as $cate) { ?>
                                <li><a class="text-decoration-none" href="cate-filter.php?cate=<?php echo $cate["cate_id"]; ?>"><?php echo $cate["cate_name"]; ?></a></li> <?php 
                            } 
                        ?>
                    </ul>
                </div>

                <div class="col-md-4 pt-5">
                    <h2 class="h2 text-light border-bottom pb-3 border-light">Thêm thông tin</h2>
                    <ul class="list-unstyled text-light footer-link-list">
                        <li><a class="text-decoration-none" href="user/index.php">Trang Chủ</a></li>
                        <li><a class="text-decoration-none" href="#">Về chúng tôi</a></li>
                        <li><a class="text-decoration-none" href="#">Store của Kan</a></li>
                        <li><a class="text-decoration-none" href="#">Câu hỏi thường gặp</a></li>
                        <li><a class="text-decoration-none" href="#">Liên Hệ</a></li>
                    </ul>
                </div>

            </div>

            <div class="row text-light mb-4">
                <div class="col-12 mb-3">
                    <div class="w-100 my-3 border-top border-light"></div>
                </div>
                <div class="col-auto me-auto">
                    <ul class="list-inline text-left footer-icons">
                        <li class="list-inline-item border border-light rounded-circle text-center">
                            <a class="text-light text-decoration-none" target="_blank" href="http://facebook.com/"><i class="fab fa-facebook-f fa-lg fa-fw"></i></a>
                        </li>
                        <li class="list-inline-item border border-light rounded-circle text-center">
                            <a class="text-light text-decoration-none" target="_blank" href="https://www.instagram.com/"><i class="fab fa-instagram fa-lg fa-fw"></i></a>
                        </li>
                        <li class="list-inline-item border border-light rounded-circle text-center">
                            <a class="text-light text-decoration-none" target="_blank" href="https://twitter.com/"><i class="fab fa-twitter fa-lg fa-fw"></i></a>
                        </li>
                        <li class="list-inline-item border border-light rounded-circle text-center">
                            <a class="text-light text-decoration-none" target="_blank" href="https://www.linkedin.com/"><i class="fab fa-linkedin fa-lg fa-fw"></i></a>
                        </li>
                    </ul>
                </div>
                <div class="col-auto">
                    <label class="sr-only" for="subscribeEmail">Email address</label>
                    <div class="input-group mb-2">
                        <input type="text" class="form-control bg-dark border-light" id="subscribeEmail" placeholder="Email address">
                        <div class="input-group-text btn-success text-light">Subscribe</div>
                    </div>
                </div>
            </div>
        </div>

        <div class="w-100 bg-black py-3">
            <div class="container">
                <div class="row pt-2">
                    <div class="col-12">
                        <p class="text-left text-light">
                            Copyright &copy; 2021 Company Name 
                            | Designed by <a rel="sponsored" href="https://templatemo.com" target="_blank">TemplateMo</a>
                        </p>
                    </div>
                </div>
            </div>
        </div>

    </footer>
    <!-- End Footer -->

    <!-- Start Script -->
    <script src="assets/js/jquery-1.11.0.min.js"></script>
    <script src="assets/js/jquery-migrate-1.2.1.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/templatemo.js"></script>
    <script src="assets/js/custom.js"></script>
    <!-- End Script -->
</body>

</html>