<?php 
    session_start();
    if(!empty($_SESSION["cart"])) {
        unset($_SESSION["cart"][$_GET["k"]]);
        echo "<script> window.location = 'cart.php'; </script>";       
    } 