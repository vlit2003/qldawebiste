<?php
    include '../src/controls.php';

    product::delete($_GET["prod"]);
    echo "<script> alert('delete success') </script>";
    echo "<script> window.location = 'product-list.php' </script>";