<?php 
    echo "<script> window.location = '../login/login-signup.php' </script>";