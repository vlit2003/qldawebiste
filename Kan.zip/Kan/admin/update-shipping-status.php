<?php 
    include '../src/controls.php';
    order::update_ship_stt($_GET["oid"], $_GET["stt"]);
    $order_id = $_GET["oid"];
    echo "<script> window.location = 'order-details.php?oid=$order_id' </script>";