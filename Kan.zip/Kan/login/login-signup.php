<?php 
	include '../src/controls.php';
	session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="login-signup.css">
	<link rel="shortcut icon" type="image/x-icon" href="user/assets/img/kkkk.jpg">
    <title>Kan Store</title>
</head>
<body>
    <div class="form-modal">  
		<div class="form-toggle">
			<button id="login-toggle" onclick="toggleLogin()">Đăng Nhập</button>
			<button id="signup-toggle" onclick="toggleSignup()">Đăng Ký</button>
		</div>

		<div id="login-form">
			<form method="post">
				<input type="text" name="login-username" placeholder="Enter email or username"/>
				<input type="password" name="password-username" placeholder="Enter password"/>
				<button type="submit" name="login-submit" class="btn login">Đăng Nhập</button>
				<p><a href="forgot-password.php">Tài khoản bị quên</a></p>
				<hr/>
			</form>

			<?php 
				if(isset($_POST["login-submit"])) {
					if(empty($_POST["login-username"]) || empty($_POST["password-username"])) {
						echo "<script> alert('Please fill out all fields completely') </script>";
					}
					else {
						$result = account::users($_POST["login-username"]);
						if($result->num_rows > 0) {
							$user_info = $result->fetch_assoc();
							if($_POST["password-username"] == $user_info["acc_password"]) {
								$_SESSION["acc_id"] = $user_info["acc_id"];
								$_SESSION["username"] = $_POST["login-username"];
								$_SESSION["role"] = $user_info["acc_role"];
								if($user_info["acc_role"] == "user") {
									echo "<script> window.location = '../user/index.php' </script>";
								}
								else {
									echo "<script> window.location = '../admin/dashboard.php' </script>";
								}							
							}
							else {
								echo "<script> alert('Incorrect password') </script>";
							}
						} else {
							echo "<script> alert('Account doesn\'t exist') </script>";
						}
					}
				}
			?>
		</div>
	
		<div id="signup-form">
			<form method="post">
				<input type="text" name="signup-username" placeholder="Choose username"/>
				<input type="password" name="signup-password" placeholder="Create password"/>
				<input type="email" name="signup-email" placeholder="Enter your email"/>
				<button type="submit" name="signup-submit" class="btn signup">Tạo tài khoản</button>
				<p>Nhấp chuột <strong>Tạo tài khoản</strong> Có nghĩa là bạn đồng ý với chúng tôi<a href="javascript:void(0)">Điều khoản dịch vụ</a>.</p>
				<hr/>		   
			</form>

			<?php 
				if(isset($_POST["signup-submit"])) {
					if(empty($_POST["signup-username"]) || empty($_POST["signup-password"]) || empty($_POST["signup-email"])) {
						echo "<script> alert('Please fill out all fields completely') </script>";
					}
					else {					
						$result = account::users($_POST["signup-username"]);

						if($result->num_rows > 0) {
							echo "<script> alert('username existed') </script>";
						} else {
							if(account::signup($_POST["signup-username"], $_POST["signup-password"], $_POST["signup-email"], "user")) {
								echo "<script> alert('signup success') </script>";
							}
						}
					}
				}
			?>
		</div>
	</div>

    <script>
		function toggleSignup(){
		   document.getElementById("login-toggle").style.backgroundColor="#fff";
		    document.getElementById("login-toggle").style.color="#222";
		    document.getElementById("signup-toggle").style.backgroundColor="#59ab6e";
		    document.getElementById("signup-toggle").style.color="#fff";
		    document.getElementById("login-form").style.display="none";
		    document.getElementById("signup-form").style.display="block";
		}

		function toggleLogin(){
		    document.getElementById("login-toggle").style.backgroundColor="#59ab6e";
		    document.getElementById("login-toggle").style.color="#fff";
		    document.getElementById("signup-toggle").style.backgroundColor="#fff";
		    document.getElementById("signup-toggle").style.color="#222";
		    document.getElementById("signup-form").style.display="none";
		    document.getElementById("login-form").style.display="block";
		}  
    </script>
</body>
</html>