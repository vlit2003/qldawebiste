<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="login-signup.css">
	<link rel="shortcut icon" type="image/x-icon" href="user/assets/img/kkkk.jpg">
    <title>Kan Store</title>
</head>
<body>
    <div class="form-modal">  
		<div class="form-toggle">
			<button id="login-toggle">Quên mật khẩu?</button>
		</div>

		<div id="login-form">
			<form method="post">
				<input type="email" name="email" placeholder="Enter your email here"/>
				<button type="submit" name="submit" class="btn login">send</button>
                <hr>
			</form>

			<?php 
                include('../src/PHPMailer/src/DSNConfigurator.php');
                include('../src/PHPMailer/src/Exception.php');
                include('../src/PHPMailer/src/OAuth.php');
                include('../src/PHPMailer/src/PHPMailer.php');
                include('../src/PHPMailer/src/POP3.php');
                include('../src/PHPMailer/src/SMTP.php');
                include('../src/controls.php');
            
                use PHPMailer\PHPMailer\PHPMailer;
                use PHPMailer\PHPMailer\Exception;  

                if(isset($_POST["submit"])) {
                    if(empty($_POST["email"])) {
                        echo "<script> alert('Please enter your email') </script>";
                    } else {
                        $result = account::get_password($_POST["email"]);
                        if($result->num_rows > 0) {
                            $password = $result->fetch_assoc()["acc_password"];
                            $mail = new PHPMailer(true);
                            try {
                                $mail->SMTPDebug = 0;
                                $mail->isSMTP();
                                $mail->Host = "smtp.gmail.com";
                                $mail->SMTPAuth = true;
                                $mail->Username = "kantran09082003@gmail.com";
                                $mail->Password = "ibtx srvb yofd xbjj";
                                $mail->SMTPSecure = "tls";
                                $mail->Port = 587;
                                $mail->CharSet = "UTF-8";
                                $mail->setFrom("kantran09082003@gmail.com");
                                $mail->addAddress($_POST["email"], 'User');
                                $mail->isHTML(true);
                                $mail->Subject = "Kan Store quên mật khẩu";
                                $mail->Body = "Mật khẩu của bạn là : " . $password;
                                $mail->send();
                                echo "<script> alert('Email đã được gửi') </script>";      
                                echo "<script> window.location = 'login-signup.php' </script>";        
                            } catch (Exception $e) {
                                echo "Tin nhắn không thể gửi. Lỗi gửi thư : " . $mail->ErrorInfo;
                            }
                        }
                    }
                }
			?>
		</div>
	</div>
</body>
</html>